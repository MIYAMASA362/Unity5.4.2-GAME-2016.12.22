﻿using UnityEngine;
using System.Collections;

public class GAMECORE : MonoBehaviour {

    //二人プレイか
    public bool Two_Player;

    //落下死亡ライン
    public float DEAD_LINE;

    //加速減速値
    public float SPEED_UP_DOWN;

	// Use this for initialization
	void Start () {

        PlayerController_1.Player2_Join_1 = Two_Player;

        PlayerController_1.DETH_LINE_1 = DEAD_LINE;

        PlayerController_1.SPEED_UP_DOWN_1 = SPEED_UP_DOWN;


        PlayerController_2.Player2_Join_2 = Two_Player;

        PlayerController_2.DETH_LINE_2 = DEAD_LINE;

        PlayerController_2.SPEED_UP_DOWN_2 = SPEED_UP_DOWN;

    }
	
	// Update is called once per frame
	void Update () {
	
	}
}
