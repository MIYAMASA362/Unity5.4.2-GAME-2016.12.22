﻿using UnityEngine;
using System.Collections;

public class JoinMove : MonoBehaviour {

    public GameObject JointObject_1;
    public GameObject JointObject_2;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

        this.transform.position = new Vector3(
            this.transform.position.x,
            this.transform.position.y,    
            JointObject_1.transform.position.z
        );

        /*float JointObject_X = 
            (JointObject_2.transform.position.x - JointObject_1.transform.position.x)/2;

        float JointObject_Z =
            (JointObject_2.transform.position.z - JointObject_2.transform.position.z)/2;

        this.transform.position = new Vector3(
            JointObject_X,
            transform.position.y,
            JointObject_Z
            );
        */
	
	}
}
